use std::collections::HashMap;
use std::sync::Arc;

use chrono::Utc;
use tokio::sync::Mutex;
use tokio_util::sync::CancellationToken;

use crate::agent::execution;
use crate::agent::task::models::{Task, TaskKind, TaskStatus};
use crate::chat::message::models::{MessageEvent, MessageRole};
use crate::inference::tool_execution::MessageTool;
use crate::chat::models::CreateChatRequest;
use crate::core::error::AppError;
use crate::core::state::AppState;
use crate::inference::InferenceResponse;

const MAX_TASK_RETRIES: usize = 10;

pub struct TaskExecutor {
    app_state: AppState,
    active_tasks: Mutex<HashMap<String, CancellationToken>>,
}

impl TaskExecutor {
    pub fn new(app_state: AppState) -> Self {
        Self {
            app_state,
            active_tasks: Mutex::new(HashMap::new()),
        }
    }

    pub async fn resume_all(self: &Arc<Self>) {
        let tasks = match self.app_state.task_service.find_resumable().await {
            Ok(tasks) => tasks,
            Err(e) => {
                tracing::error!(error = %e, "Failed to query resumable tasks");
                return;
            }
        };

        if tasks.is_empty() {
            return;
        }

        tracing::info!(count = tasks.len(), "Resuming tasks from previous run");

        for task in tasks {
            if task.status == TaskStatus::Cancelled {
                continue;
            }

            if let Err(e) = self.spawn_execution(task).await {
                tracing::warn!(error = %e, "Failed to spawn task during resume");
            }
        }
    }

    pub async fn spawn_execution(self: &Arc<Self>, task: Task) -> Result<(), AppError> {
        if self.app_state.is_shutting_down() {
            tracing::info!(task_id = %task.id, "Rejecting task spawn during shutdown");
            return Ok(());
        }

        let active = self.active_tasks.lock().await;
        if active.len() >= self.app_state.max_concurrent_tasks {
            tracing::info!(
                task_id = %task.id,
                active = active.len(),
                limit = self.app_state.max_concurrent_tasks,
                "Global concurrency limit reached, task stays Pending"
            );
            return Ok(());
        }

        let agent_max = self.get_agent_concurrent_limit(&task.agent_id).await;
        let agent_active_count = active
            .keys()
            .filter(|k| k.starts_with(&format!("{}:", task.agent_id)))
            .count();

        if agent_active_count >= agent_max {
            tracing::info!(
                task_id = %task.id,
                agent_id = %task.agent_id,
                active = agent_active_count,
                limit = agent_max,
                "Per-agent concurrency limit reached, task stays Pending"
            );
            return Ok(());
        }
        drop(active);

        let cancel_token = CancellationToken::new();
        let key = format!("{}:{}", task.agent_id, task.id);
        self.active_tasks
            .lock()
            .await
            .insert(key.clone(), cancel_token.clone());

        let executor = Arc::clone(self);
        let task_id = task.id.clone();

        tokio::spawn(async move {
            let result = executor.execute_task(task, cancel_token).await;
            executor.active_tasks.lock().await.remove(&key);

            if let Err(e) = result {
                tracing::error!(error = %e, task_id = %task_id, "Task execution failed");
            }
        });

        Ok(())
    }

    pub async fn cancel_task(&self, task_id: &str) -> bool {
        let active = self.active_tasks.lock().await;
        for (key, token) in active.iter() {
            if key.ends_with(&format!(":{}", task_id)) {
                token.cancel();
                return true;
            }
        }
        false
    }

    async fn get_agent_concurrent_limit(&self, agent_id: &str) -> usize {
        if let Ok(Some(agent)) = self.app_state.agent_service.find_by_id(agent_id).await {
            return agent.max_concurrent_tasks.unwrap_or(3) as usize;
        }
        3
    }

    async fn execute_task(
        self: &Arc<Self>,
        mut task: Task,
        cancel_token: CancellationToken,
    ) -> Result<(), AppError> {
        let task_id = task.id.clone();

        let current_status = self
            .app_state
            .task_service
            .find_by_id(&task_id)
            .await?
            .map(|t| t.status);

        if matches!(current_status, Some(TaskStatus::Cancelled)) {
            tracing::info!(task_id = %task_id, "Task already cancelled, skipping");
            return Ok(());
        }

        let chat_id = self.ensure_task_chat(&mut task).await?;

        self.app_state
            .task_service
            .mark_in_progress(&task_id, Some(&chat_id))
            .await?;

        self.broadcast_task_status(&task, "inprogress", None);
        self.save_initial_message_if_needed(&task, &chat_id).await?;

        for turn in 0..MAX_TASK_RETRIES {
            // Check for unprocessed lifecycle events (crash recovery)
            if let Some(action) = self.find_lifecycle_event(&chat_id).await {
                self.handle_lifecycle_action(&task, &chat_id, action)
                    .await?;
                return Ok(());
            }

            let continuation_prompt = if turn > 0 {
                self.app_state.prompts.read("TASK_CONTINUATION.md")
            } else {
                None
            };

            // Create or find an Executing agent message for this turn
            let agent_msg_id = match self.app_state.chat_service
                .find_executing_message_for_chat(&chat_id)
                .await
            {
                Ok(Some(msg)) => msg.id,
                _ => {
                    let msg = self.app_state.chat_service
                        .create_executing_agent_message(&chat_id, &task.agent_id)
                        .await?;
                    msg.id
                }
            };

            let session_token = self.app_state.active_sessions.register(&chat_id).await;
            let result = execution::run_agent_loop(
                &self.app_state,
                &task.user_id,
                &chat_id,
                &agent_msg_id,
                cancel_token.clone(),
                true,
                continuation_prompt.as_deref(),
            )
            .await;
            drop(session_token);
            self.app_state.active_sessions.remove(&chat_id).await;

            match result {
                Ok(execution::AgentLoopOutcome { response }) => match response {
                    InferenceResponse::Completed { text, attachments, lifecycle_event, reasoning, .. } => {
                        let _ = self.app_state.chat_service
                            .complete_agent_message(&agent_msg_id, text.clone(), attachments, reasoning)
                            .await;

                        if let Some(event) = lifecycle_event {
                            let action = self.lifecycle_action_from_event(
                                event,
                                &text,
                            );
                            self.handle_lifecycle_action(&task, &chat_id, action)
                                .await?;
                            return Ok(());
                        }

                        if let Some(action) = self.find_lifecycle_event(&chat_id).await {
                            self.handle_lifecycle_action(&task, &chat_id, action)
                                .await?;
                            return Ok(());
                        }
                        continue;
                    }
                    InferenceResponse::ExternalToolPending { .. } => {
                        // Tool loop already persisted all tool executions
                        self.wait_for_resolution(&task.id, &cancel_token).await?;
                        continue;
                    }
                    InferenceResponse::Cancelled(text) => {
                        let _ = self.app_state.chat_service
                            .complete_agent_message(&agent_msg_id, text, vec![], None)
                            .await;
                        self.handle_cancelled(&task).await?;
                        return Ok(());
                    }
                },
                Err(e) => {
                    let _ = self.app_state.chat_service
                        .fail_agent_message(&agent_msg_id).await;
                    self.handle_error(&task, &e).await?;
                    return Ok(());
                }
            }
        }

        // Max outer turns reached — auto-complete
        tracing::warn!(
            task_id = %task.id,
            turns = MAX_TASK_RETRIES,
            "Task reached max retries, auto-completing"
        );
        self.app_state
            .task_service
            .mark_completed(&task.id, Some("Task auto-completed after max retries".into()))
            .await?;
        self.deliver_to_source(
            &task,
            TaskStatus::Completed,
            "Task auto-completed after max retries".into(),
        )
        .await;
        self.broadcast_task_status(&task, "completed", Some("Task auto-completed after max retries"));

        Ok(())
    }

    // --- Lifecycle event scanning ---

    async fn find_lifecycle_event(&self, chat_id: &str) -> Option<LifecycleAction> {
        let messages = self.app_state.chat_service.get_stored_messages(chat_id).await;

        // Find the last assistant message to use as fallback summary
        let last_assistant_content = messages
            .iter()
            .rev()
            .find(|m| m.role == MessageRole::Agent && !m.content.is_empty())
            .map(|m| m.content.clone());

        for msg in messages.iter().rev() {
            if msg.role != MessageRole::System {
                continue;
            }
            match &msg.event {
                Some(MessageEvent::TaskCompletion {
                    status, summary, ..
                }) => {
                    let resolved_summary = summary
                        .clone()
                        .or(last_assistant_content)
                        .unwrap_or_default();
                    return Some(LifecycleAction::Complete {
                        status: status.clone(),
                        summary: resolved_summary,
                    });
                }
                Some(MessageEvent::TaskDeferred {
                    delay_minutes,
                    reason,
                    ..
                }) => {
                    return Some(LifecycleAction::Defer {
                        delay_minutes: *delay_minutes,
                        reason: reason.clone(),
                    });
                }
                _ => continue,
            }
        }
        None
    }

    fn lifecycle_action_from_event(
        &self,
        event: MessageTool,
        fallback_summary: &str,
    ) -> LifecycleAction {
        match event {
            MessageTool::TaskCompletion { status, summary, .. } => {
                let resolved_summary = summary
                    .or_else(|| {
                        if fallback_summary.is_empty() { None } else { Some(fallback_summary.to_string()) }
                    })
                    .unwrap_or_default();
                LifecycleAction::Complete { status, summary: resolved_summary }
            }
            MessageTool::TaskDeferred { delay_minutes, reason, .. } => {
                LifecycleAction::Defer { delay_minutes, reason }
            }
            _ => LifecycleAction::Complete {
                status: TaskStatus::Completed,
                summary: fallback_summary.to_string(),
            },
        }
    }

    async fn handle_lifecycle_action(
        &self,
        task: &Task,
        _chat_id: &str,
        action: LifecycleAction,
    ) -> Result<(), AppError> {
        match action {
            LifecycleAction::Complete {
                status: TaskStatus::Completed,
                summary,
            } => {
                self.app_state
                    .task_service
                    .mark_completed(&task.id, Some(summary.clone()))
                    .await?;
                self.deliver_to_source(task, TaskStatus::Completed, summary.clone())
                    .await;
                self.broadcast_task_status(task, "completed", Some(&summary));
            }
            LifecycleAction::Complete {
                status: TaskStatus::Failed,
                summary,
            } => {
                self.app_state
                    .task_service
                    .mark_failed(&task.id, summary.clone())
                    .await?;
                self.deliver_to_source(task, TaskStatus::Failed, summary)
                    .await;
                self.broadcast_task_status(task, "failed", None);
            }
            LifecycleAction::Complete { .. } => {}
            LifecycleAction::Defer {
                delay_minutes,
                reason,
            } => {
                let run_at = Utc::now() + chrono::Duration::minutes(delay_minutes as i64);
                self.app_state
                    .task_service
                    .mark_deferred(&task.id, run_at, &reason)
                    .await?;
                self.broadcast_task_status(task, "deferred", Some(&reason));
            }
        }
        Ok(())
    }

    // --- Resolution waiter ---

    async fn wait_for_resolution(
        &self,
        task_id: &str,
        cancel_token: &CancellationToken,
    ) -> Result<(), AppError> {
        let notify = Arc::new(tokio::sync::Notify::new());
        {
            let mut notifiers = self.app_state.task_resolution_notifiers.lock().await;
            notifiers.insert(task_id.to_string(), notify.clone());
        }

        tokio::select! {
            () = notify.notified() => {}
            () = cancel_token.cancelled() => {}
        }

        {
            let mut notifiers = self.app_state.task_resolution_notifiers.lock().await;
            notifiers.remove(task_id);
        }

        Ok(())
    }

    // --- Helpers ---

    pub async fn ensure_task_chat(&self, task: &mut Task) -> Result<String, AppError> {
        if let Some(ref cid) = task.chat_id {
            return Ok(cid.clone());
        }

        let chat = self
            .app_state
            .chat_service
            .create_chat(
                &task.user_id,
                CreateChatRequest {
                    space_id: task.space_id.clone(),
                    task_id: Some(task.id.clone()),
                    agent_id: task.agent_id.clone(),
                    title: Some(format!("Task: {}", task.title)),
                },
            )
            .await?;
        task.chat_id = Some(chat.id.clone());
        Ok(chat.id)
    }

    pub async fn save_initial_message_if_needed(
        &self,
        task: &Task,
        chat_id: &str,
    ) -> Result<(), AppError> {
        let stored_messages = self.app_state.chat_service.get_stored_messages(chat_id).await;
        if !stored_messages.is_empty() {
            return Ok(());
        }

        let source_agent_id = match &task.kind {
            TaskKind::Delegation {
                source_agent_id, ..
            } => source_agent_id.as_str(),
            _ => &task.agent_id,
        };
        self.app_state
            .chat_service
            .save_agent_message(chat_id, source_agent_id, task.description.clone())
            .await?;
        Ok(())
    }

    pub async fn handle_cancelled(
        &self,
        task: &Task,
    ) -> Result<(), AppError> {
        self.app_state
            .task_service
            .mark_cancelled(&task.id)
            .await?;
        self.broadcast_task_status(task, "cancelled", None);
        Ok(())
    }

    pub async fn handle_error(&self, task: &Task, error: &AppError) -> Result<(), AppError> {
        let error_msg = format!("Task execution error: {}", error);
        tracing::error!(error = %error, task_id = %task.id, "Task execution failed");
        self.app_state
            .task_service
            .mark_failed(&task.id, error_msg)
            .await?;
        self.deliver_to_source(task, TaskStatus::Failed, error.to_string())
            .await;
        self.broadcast_task_status(task, "failed", None);
        Ok(())
    }

    pub async fn deliver_to_source(&self, task: &Task, status: TaskStatus, text: String) {
        let TaskKind::Delegation {
            ref source_chat_id,
            deliver_directly,
            ..
        } = task.kind
        else {
            return;
        };

        let attachments = if status == TaskStatus::Completed {
            task.chat_id.as_ref().map(|cid| {
                self.app_state
                    .chat_service
                    .find_attachments_by_chat_id(cid)
            })
        } else {
            None
        };

        let attachments = match attachments {
            Some(fut) => fut.await.unwrap_or_default(),
            None => vec![],
        };

        let event = MessageEvent::TaskCompletion {
            task_id: task.id.clone(),
            chat_id: task.chat_id.clone(),
            status,
            summary: Some(text.clone()),
        };

        match self
            .app_state
            .chat_service
            .save_task_completion_message(source_chat_id, &task.agent_id, text, event, attachments)
            .await
        {
            Ok(msg) => {
                self.app_state.broadcast_service.broadcast_chat_message(
                    &task.user_id,
                    source_chat_id,
                    msg,
                );
            }
            Err(e) => {
                tracing::warn!(error = %e, task_id = %task.id, "Failed to deliver task result to source chat");
            }
        }

        if !deliver_directly {
            self.check_and_resume_parent(source_chat_id, &task.user_id)
                .await;
        }
    }

    async fn check_and_resume_parent(&self, source_chat_id: &str, user_id: &str) {
        // Only resume the parent if the source chat belongs to a task.
        // For user chats, just deliver the message — don't trigger the agent.
        let is_task_chat = matches!(
            self.app_state.chat_service.find_chat(source_chat_id).await,
            Ok(Some(chat)) if chat.task_id.is_some()
        );
        if !is_task_chat {
            return;
        }

        let siblings = match self
            .app_state
            .task_service
            .find_by_source_chat_id(source_chat_id)
            .await
        {
            Ok(s) => s,
            Err(e) => {
                tracing::warn!(error = %e, "Failed to query sibling tasks");
                return;
            }
        };

        let all_done = siblings.iter().all(|t| {
            matches!(
                t.status,
                TaskStatus::Completed | TaskStatus::Failed | TaskStatus::Cancelled
            )
        });

        if !all_done {
            tracing::debug!(
                source_chat_id = %source_chat_id,
                remaining = siblings.iter().filter(|t| matches!(t.status, TaskStatus::Pending | TaskStatus::InProgress)).count(),
                "Not all sibling tasks done yet"
            );
            return;
        }

        tracing::info!(
            source_chat_id = %source_chat_id,
            "All child tasks complete, resuming parent"
        );

        let state = self.app_state.clone();
        let user_id = user_id.to_string();
        let chat_id = source_chat_id.to_string();
        tokio::spawn(async move {
            let message_id = match state.chat_service
                .find_executing_message_for_chat(&chat_id)
                .await
            {
                Ok(Some(msg)) => msg.id,
                Ok(None) => {
                    tracing::warn!(chat_id = %chat_id, "No executing message found for child task resume");
                    return;
                }
                Err(e) => {
                    tracing::error!(error = %e, chat_id = %chat_id, "Failed to find executing message");
                    return;
                }
            };
            resume_or_notify(&state, &user_id, &chat_id, &message_id).await;
        });
    }

    pub fn broadcast_task_status(&self, task: &Task, status: &str, summary: Option<&str>) {
        self.app_state.broadcast_service.broadcast_task_update(
            &task.user_id,
            &task.id,
            status,
            &task.title,
            task.chat_id.as_deref(),
            task.kind.source_chat_id(),
            summary,
        );
    }
}

enum LifecycleAction {
    Complete {
        status: TaskStatus,
        summary: String,
    },
    Defer {
        delay_minutes: u32,
        reason: String,
    },
}

/// Check if a task executor is waiting for resolution on this chat's task.
/// If so, notify it. Otherwise, fall back to `resume_agent_loop`.
pub async fn resume_or_notify(state: &AppState, user_id: &str, chat_id: &str, message_id: &str) {
    // Check if this chat belongs to a task with a waiting executor
    if let Ok(Some(chat)) = state.chat_service.find_chat(chat_id).await
        && let Some(ref task_id) = chat.task_id
    {
        let notifiers = state.task_resolution_notifiers.lock().await;
        if let Some(notify) = notifiers.get(task_id) {
            notify.notify_one();
            return;
        }
    }

    // No waiting executor — use the interactive path
    if let Err(e) = crate::agent::execution::resume_agent_loop(state, user_id, chat_id, message_id).await {
        tracing::error!(error = %e, chat_id = %chat_id, "Failed to resume chat");
    }
}
